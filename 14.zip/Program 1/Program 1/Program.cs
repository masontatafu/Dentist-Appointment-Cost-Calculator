﻿using System.Numerics;
using System.Runtime.CompilerServices;
// Name: Mason Tatafu
// Date: 02/14/2024
// Work: Program 1
// Course: CIS199-50-4242
// Grading ID: S2407
// The following program prompts the user to enter a few bits of information,
// this information is then used to calculate the cost of their dentist appointment
// this cost is returned back to the user after the calculations have occured
namespace program
{
    class Program
    {
        static void Main(string[] args)
        {
            // the following lines are user input prompts, and assigning variables to their inputs
            Console.WriteLine("Please enter your name: ");
            string client_name = Console.ReadLine();

            Console.WriteLine("What is your procedure type?");
            string client_procedure = Console.ReadLine();

            Console.WriteLine("What is the duration of your procedure in hours?");
            string client_hours = Console.ReadLine();

            Console.WriteLine("What is the amount of material needed in ounces?");
            string client_material = Console.ReadLine();

            Console.WriteLine("How many additional staff are needed?");
            string client_staffneed = Console.ReadLine();   

            Console.WriteLine("Are you a senior citizen?\n Type 1 for Yes, Type 0 for No");
            string client_senior = Console.ReadLine();

            //initializing some variables for later use
            double duration;
            double material;
            int staff;
            int senior;

            //turning variables into appropriate data types
            duration = Double.Parse(client_hours);
            material = Double.Parse(client_material);
            staff = int.Parse(client_staffneed);
            senior = int.Parse(client_senior);

            //assigning respective values to variables
            double consult_fee = 100;
            double discount = 0.1;
            double staff_fee = 25;
            double material_cost = 0.1;

            //calculations of costs
            double cost = Math.Round(consult_fee + (duration * 50) + (duration * staff * staff_fee) + (material * material_cost), 2);
            double discounted_cost = Math.Round(cost - (cost * discount), 2);

            //the following if statements were used to determine if discount was appropriate 
            //also added in error case where if the user didn't type valid input, they are told so
            if(senior==1)
            {
                Console.WriteLine("Price Quote:\nName: " + client_name + "\nProcedure Type: " + client_procedure + "\nDuration: " + client_hours);
                Console.WriteLine("Your total cost is: " + discounted_cost);  
            }
            if(senior==0)
            {
                Console.WriteLine("Price Quote:\nName: " + client_name + "\nProcedure Type: " + client_procedure + "\nDuration: " + client_hours);
                Console.WriteLine("Your total cost is: " + cost); 
            }
            if(senior!=1 && senior !=0)
            {
                Console.WriteLine("You did not enter '1' or '0', please retry.");
                return;
            }
        }
    }
}



